var config = {
    paths: {
        "bxslider": "ViMagento_Banner/js/jquery.bxslider.min"
    },
    shim: {
        "bxslider": ["jquery"]
    }
};
